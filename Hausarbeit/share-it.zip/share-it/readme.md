# Readme

## Hinweise

Um das Projekt starten zu können müssen folgende commands eingegben werden:

1. ...