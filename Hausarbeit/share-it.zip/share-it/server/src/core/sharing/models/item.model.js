
class Item{
    constructor() {
        
    }
}