
class Item{
    constructor() {
        
    }
}