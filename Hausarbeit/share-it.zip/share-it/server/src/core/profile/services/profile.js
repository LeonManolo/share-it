class Profile {}

module.exports = Profile;
